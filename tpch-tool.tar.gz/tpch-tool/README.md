TPCH data generation quick guide

## Prerequisites
- Already built in `TPCH/dbgen` and can run `./dbgen`.
- If not built yet, run `make` in that directory (requires `make` and a C compiler).

## Basic usage
- Enter the directory: `cd TPCH/dbgen`
- Generate data: `./dbgen -T <TABLES> -s <SCALE> -f`
  - `-T`: tables to generate, uppercase letters combined (e.g., `L` for `lineitem`, `O` for `orders`; omit to generate all tables).
  - `-s`: Scale Factor. `-s 1` is roughly a 1GB full kit (8 tables total, `lineitem` is ~70%).
  - `-f`: overwrite any existing output files of the same name.
  - Output filenames default to `<table>.tbl`.

## Command template
```
cd TPCH/dbgen && ./dbgen -T {TABLES} -s {SCALE} -f
```
- `{TABLES}` examples: `L` (lineitem only), `LO` (lineitem + orders), leave empty for all tables.
- `{SCALE}` examples: `1` (~1GB full kit), `10` (~10GB full kit).

## Examples
- Generate 1GB-scale lineitem only and rename to `lineitem.1`:
  ```
  cd TPCH/dbgen && ./dbgen -T L -s 1 -f && mv -f lineitem.tbl lineitem.1
  ```
- Generate 10GB full dataset (all tables):
  ```
  cd TPCH/dbgen && ./dbgen -s 10 -f
  ```

## Output files
- Each table is a `.tbl` file (pipe `|` delimited, no header).
- Use `ls -lh *.tbl` to check sizes; move or rename as needed.
